package com.mycompany.projetofinal;

import java.util.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class GerSocial{

	private Social soc;
	private List<Social> bdSocial;
        private static GerSocial gpUnic;
        
        private GerSocial(){
            bdSocial = new ArrayList<Social>();
        }
        
        //Singleton
        public static GerSocial geraGerSocial(){
            if(gpUnic == null){
                gpUnic = new GerSocial();
            }
            return gpUnic;
        }
      
        public List<Social> getBdSocial(){
            return bdSocial;
        }
        
	public Social insSoci(Social soc){
		if(consSoci(soc)== null){
			bdSocial.add(soc);
			return soc;
		}
		else{
			return null;
		}
	}

	public Social consSoci(Social soc){
		for(int i = 0; i < bdSocial.size(); i++){
			if(soc.getIdsapato() == bdSocial.get(i).getIdsapato()){
				return bdSocial.get(i);
			}
		}
		return null;
	}

	public Social delSoci(Social soc){
                Social soc1 = consSoci(soc);
            	if(soc1 != null){
                    bdSocial.remove(soc1);
                    return null;
		}
		else{
                    return soc;
		}
		
	}

	public Social atualSoci(Social soc){
		for(int i = 0; i < bdSocial.size(); i++){
			if(soc.getIdsapato() == bdSocial.get(i).getIdsapato()){
				soc = bdSocial.get(i);
                                
                                String idsapato = JOptionPane.showInputDialog(
                                        null,
                                        "Informe o novo NOME",
                                        "Atualizar dados",
                                        JOptionPane.INFORMATION_MESSAGE
                                );

                                soc.setIdsapato(Integer.parseInt(idsapato));
				bdSocial.set(i, soc);  
                                return bdSocial.get(i);
			}
		}
                return null;
	}

}
