//Nome: André Troise Agostinis
//RA: 2564106

package com.mycompany.projetofinal;

public abstract class Sapato implements Valor{

        private int idsapato;
	private double preco = 0;
	private double desconto = 0;
	private Tipo t;
	protected int escolha;

	public Sapato() {
		preco = 0.0;
		desconto = 0.0;
                idsapato = 0;
		t = new Tipo();
		escolha = 0;
	}

	public Sapato(int idsapato, double preco, double desconto, Tipo t, int escolha) {
                this.idsapato = idsapato;
		this.preco = preco;
		this.desconto = desconto;
		this.t = t;
		this.escolha = escolha;
	}
        
        public int getIdsapato(){
                return idsapato;
        }

	public double getPreco(){
		return preco;
	}

	public double getDesconto(){
		return desconto;
	}

	public Tipo getT(){
		return t;
	}

	public int getEscolha(){
		return escolha;
	}
        
        public void setIdsapato(int idsapato){
                this.idsapato = idsapato;
        }

	public void setPreco(double preco){
		this.preco = preco;
	}

	public void setDesconto(double desconto){
		this.desconto = desconto;
	}

	public void setT(Tipo t){
		this.t = t;
	}

	public void setEscolha(int escolha){
		this.escolha = escolha;
	}

	public double calc(){
		return getPreco() - getDesconto();
	}

}