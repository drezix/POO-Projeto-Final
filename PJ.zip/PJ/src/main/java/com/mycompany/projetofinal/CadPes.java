/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/*
package com.mycompany.primprojads;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aluno
 */
/*
public class CadPes extends javax.swing.JFrame {
    private Pessoa p1 = new Pessoa();
    private GerPes gp = GerPes.geraGerPes();
    private static CadPes cpUnic;
    
    private CadPes() {
        initComponents();
    }
    //Singleton
    public static CadPes geraCadPes(){
        if(cpUnic == null){
            cpUnic = new CadPes();
        }
        return cpUnic;
   }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rtCpf = new javax.swing.JLabel();
        cxCpf = new javax.swing.JTextField();
        rtNome = new javax.swing.JLabel();
        cxNome = new javax.swing.JTextField();
        btLimpar = new javax.swing.JButton();
        btSair = new javax.swing.JButton();
        btInsPes = new javax.swing.JButton();
        btCosPesCpf = new javax.swing.JButton();
        btAltPesCpf = new javax.swing.JButton();
        btExcPesCpf = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbPes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        rtCpf.setText("CPF:");

        rtNome.setText("NOME:");

        btLimpar.setText("Limpar");
        btLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLimparActionPerformed(evt);
            }
        });

        btSair.setText("Sair");
        btSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSairActionPerformed(evt);
            }
        });

        btInsPes.setText("Inserir");
        btInsPes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btInsPesActionPerformed(evt);
            }
        });

        btCosPesCpf.setText("Consutar CPF");
        btCosPesCpf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCosPesCpfActionPerformed(evt);
            }
        });

        btAltPesCpf.setText("Alterar CPF");
        btAltPesCpf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAltPesCpfActionPerformed(evt);
            }
        });

        btExcPesCpf.setText("Excluir CPF");
        btExcPesCpf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btExcPesCpfActionPerformed(evt);
            }
        });

        tbPes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "CPF", "NOME"
            }
        ));
        tbPes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbPesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbPes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btLimpar)
                .addGap(18, 18, 18)
                .addComponent(btSair)
                .addGap(280, 280, 280))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btInsPes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btCosPesCpf)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btAltPesCpf)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btExcPesCpf))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(rtNome)
                                    .addComponent(rtCpf))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cxNome, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cxCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rtCpf)
                    .addComponent(cxCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rtNome)
                    .addComponent(cxNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btInsPes)
                    .addComponent(btCosPesCpf)
                    .addComponent(btAltPesCpf)
                    .addComponent(btExcPesCpf))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btLimpar)
                    .addComponent(btSair))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
/*
    private void btLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLimparActionPerformed
        limpar();
    }//GEN-LAST:event_btLimparActionPerformed

    private void btSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSairActionPerformed
        sair();
    }//GEN-LAST:event_btSairActionPerformed

    private void btInsPesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btInsPesActionPerformed
        insPes();
        listTab();
        limpar();
    }//GEN-LAST:event_btInsPesActionPerformed

    private void btCosPesCpfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCosPesCpfActionPerformed
       consPesCpf();
    }//GEN-LAST:event_btCosPesCpfActionPerformed

    private void btAltPesCpfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAltPesCpfActionPerformed
        altPesCpf();
        listTab();
    }//GEN-LAST:event_btAltPesCpfActionPerformed

    public void listTab(){
        DefaultTableModel modelo = (DefaultTableModel)tbPes.getModel();
        int posLin = 0;
        
        modelo.setRowCount(posLin);
        
        for(Pessoa pes:gp.getBdPes()){ //for each
            modelo.insertRow(posLin, new Object[]{pes.getCpf(),pes.getNome()});
            posLin++;
        }
    }
    
    public void selectTab(){
    
        String valLinTab = "";
        
        int posLin = tbPes.getSelectedRow();
        int col = 0;
        for(col = 0; col < tbPes.getColumnCount(); col++){
            valLinTab += tbPes.getModel().getValueAt(posLin, col).toString();
            
            if(col+1 < tbPes.getColumnCount()){
                valLinTab += " - ";
            }
        }
        
        JOptionPane.showMessageDialog(
                null,
                "Conteudo: "+valLinTab,
                "VALORES DA LINHA --> "+col,
                1
        );
    }
    /*
    private void btExcPesCpfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btExcPesCpfActionPerformed
        excPesCpf();
        listTab();
    }//GEN-LAST:event_btExcPesCpfActionPerformed

    private void tbPesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbPesMouseClicked
        selectTab();
    }//GEN-LAST:event_tbPesMouseClicked
    public void excPesCpf(){
           p1 = new Pessoa();
        
        p1.setCpf(Integer.parseInt(cxCpf.getText()));
        
        p1 = gp.delPesCpf(p1);
        
        if(p1 == null){
           
            JOptionPane.showMessageDialog(
                    null,
                    "Pessoa excluida com sucesso!",
                    "EXCLUSÃO DE PESSOA",
                    1
            );
            limpar();
        }
        else{
                    JOptionPane.showMessageDialog(
                    null,
                    "NÃO EXISTE PESSOA COM ESTE CPF",
                    "EXCLUSÃO DE PESSOA",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    public void altPesCpf(){
        p1 = new Pessoa();
        
        p1.setCpf(Integer.parseInt(cxCpf.getText()));
        
        p1 = gp.atualizaPesCpf(p1);
        
        if(p1 != null){
            cxCpf.setText(Integer.toString(p1.getCpf()));
            cxNome.setText(p1.getNome());
            
            JOptionPane.showMessageDialog(
                    null,
                    "Confira do dados!",
                    "ALTERAÇÃO DE PESSOA",
                    1
            );
            limpar();
        }
        else{
                    JOptionPane.showMessageDialog(
                    null,
                    "NÃO EXISTE PESSOA COM ESTE CPF",
                    "ALTERAÇÃO DE PESSOA",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    public void consPesCpf(){
        p1 = new Pessoa();
        
        p1.setCpf(Integer.parseInt(cxCpf.getText()));
        
        p1 = gp.consPesCpf(p1);
        
        if(p1 != null){
            cxCpf.setText(Integer.toString(p1.getCpf()));
            cxNome.setText(p1.getNome());
            
            JOptionPane.showMessageDialog(
                    null,
                    "Pessoa encontradas com sucesso! - Verifique os dados",
                    "CONSULTA DE PESSOA",
                    1
            );
        }
        else{
                    JOptionPane.showMessageDialog(
                    null,
                    "nÃO EXISTE PESSOA COM ESTE CPF",
                    "CONSULTA DE PESSOA",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        limpar();
    }
    public void insPes(){
        try{
            p1 = new Pessoa();

            p1.setCpf(Integer.parseInt(cxCpf.getText()));
            p1.setNome(cxNome.getText());

            p1 = gp.insPes(p1);

            if(p1 != null){
                JOptionPane.showMessageDialog(
                        null,
                        "Pessoa cadastrada com sucesso!",
                        "CADASTRO DE PESSOA",
                        1
                );
            }
            else{
                JOptionPane.showMessageDialog(
                        null,
                        "CPF duplicado",
                        "CADASTRO DE PESSOA",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }//fim try
        catch(NumberFormatException nfe){
                JOptionPane.showMessageDialog(
                        null,
                        "Valor do CPF deve ser um inteiro",
                        "Erro de tipo de dados",
                        JOptionPane.ERROR_MESSAGE
                ); 
                cxCpf.setText("");
                cxCpf.requestFocus();
        }
        
    }
    
    public void sair(){
        int resp = JOptionPane.showConfirmDialog(
                null,
                "Deseja realmente sair?",
                "SAIR",
                JOptionPane.YES_NO_OPTION
        );
        if(resp == 0){
            dispose();
        }
    }
    
    public void limpar(){
        cxCpf.setText("");
        cxNome.setText("");
        cxCpf.requestFocus();
    }
    
    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
    /*
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadPes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadPes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadPes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadPes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        /*
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadPes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAltPesCpf;
    private javax.swing.JButton btCosPesCpf;
    private javax.swing.JButton btExcPesCpf;
    private javax.swing.JButton btInsPes;
    private javax.swing.JButton btLimpar;
    private javax.swing.JButton btSair;
    private javax.swing.JTextField cxCpf;
    private javax.swing.JTextField cxNome;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel rtCpf;
    private javax.swing.JLabel rtNome;
    private javax.swing.JTable tbPes;
    // End of variables declaration//GEN-END:variables
}
*/
