//Nome: André Troise Agostinis
//RA: 2564106

package com.mycompany.projetofinal;

public class Tipo{
    
    private int tamanho;
    private String cor = "";

    public Tipo(){
        tamanho = 0;
        cor = "";
    }

    public int getTamanho(){
        return tamanho;
    }
    
    public String getCor(){
        return cor;
    }

    public void setTamanho(int tamanho){
        this.tamanho = tamanho;
    }
    
    public void setCor(String cor){
        this.cor = cor;
    }
    
    
}
