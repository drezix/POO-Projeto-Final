//Nome: André Troise Agostinis
//RA: 2564106 

package com.mycompany.projetofinal;

public final class Social extends Sapato {
    
    public final static String modelo1 = "SOCIAL";
    private String palmilha;
    private String couro;
    private String forma;

    public Social() {
        palmilha = "";
        couro = "";
        forma = "";
    }

    public Social(int idsapato, double preco, double desconto, Tipo t, int escolha, String material, String palmilha, String couro, String forma) {
        super(idsapato, preco, desconto, t, escolha);
        this.palmilha = palmilha;
        this.couro = couro;
        this.forma = forma;
    }   

    public String getPalmilha() {
        return palmilha;
    }

    public String getCouro() {
        return couro;
    }

    public String getForma() {
        return forma;
    }

    public void setPalmilha(String palmilha) {
        this.palmilha = palmilha;
    }

    public void setCouro(String couro) {
        this.couro = couro;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }

}
