//Nome: André Troise Agostinis
//RA: 2564106

package com.mycompany.projetofinal;

public interface Valor {
	double calc();
}
